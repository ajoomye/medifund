# config.py

CONTRACT_ADDRESS = "0x16871fD4A0fcB3372b44A53002a933D1B5947475" 


NETWORK = "https://base-sepolia.infura.io/v3/eaa2d6d2fd2c4019935a2d451cd57c59"  # Replace with your Infura project URL

#NETWORK = "http://127.0.0.1:8545"